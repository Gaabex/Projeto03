const express = require("express");

const router = express.Router()

router.get('/',(req, res) =>{
    res.send("Ola Mundo... UNICSUL");
});

router.get('/rota1',(req, res) =>{
    res.send("UNICSUL - ROTA 1")
});

router.get('/rota2',(req, res) =>{
    res.send("Perdeu Mane...")
});

const app = express()
app.use('/', router);

module.exports = app;
