const app = require('./app');

//importando e configurando o dotenv
require('dotenv').config({path:'variables.env'});

console.log("EU me chamo: "+ process.env.NOME+ " e eu tenho: "+ process.env.IDADE);

//Configurando Servidor
app.set('port',process.env.PORT || 7777 || 8080 || 1000);
const server =  app.listen(app.get('port'),() =>{
    console.log("Servidor Rodando na porta: " +server.address().port);
});